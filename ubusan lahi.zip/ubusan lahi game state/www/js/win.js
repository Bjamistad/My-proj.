winGame={
	create:function () {

// game._leftTimeText.kill();
    // game.paused=true;
	},

}