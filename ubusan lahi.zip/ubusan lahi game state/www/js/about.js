aboutGame = {
    create: function(){
            game.add.sprite(0,0,"back");
    menuText  = game.add.text(20,50,"ABOUT :",{"fill":"BLACK"});
    menuText.scale.x = 2;
    menuText.scale.y = 2;
    }, 
    update: function(){

    }
};    
